package pl.mkorcz.FilmWeb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilmWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(FilmWebApplication.class, args);
	}

}
