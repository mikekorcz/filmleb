package pl.mkorcz.FilmWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilmWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
